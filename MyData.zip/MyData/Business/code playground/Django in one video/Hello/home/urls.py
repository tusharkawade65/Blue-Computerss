from Hello.settings import STATIC_URL
from django.contrib import admin
from django.urls import path
from home import views
from django.conf.urls.static import static
from django.conf import settings

import home

urlpatterns = [
    path("", views.index, name='home'),

    path("latest/", views.latest, name='latest'),
    path("about/", views.about, name='about'),
    path("populer/", views.populer, name='services'),
    path("contact/", views.contacts, name='contacts'),
    path("logout/", views.logout, name='Logout'),
    path("index",views.index, name='index'),
    path("productView/<int:pk>", views.productView, name='productView'),
    path("buynow/<int:pk2>", views.buynow, name='buynow'),
    path("orderReceipt/<int:pk3>", views.orderReceipt, name='orderReceipt'),
    path("allorders/", views.allorders, name='allorders'),
    path("orderplaced/", views.orderplaced, name='orderplaced'),
    path("newlogin", views.newlogin, name='newlogin'),
    path("newregister", views.newregister, name='newregister'),
    path("cart/", views.usercart, name='cart'),
    path("removeproductfromcart/<int:pk>", views.removeproductfromcart, name='removeproductfromcart'),
    path("addtocart/<int:pk>",views.addtocart,name='addtocart'),
    path("allcartaddtoorders/",views.allcartaddtoorders,name='allcartaddtoorders'),
    path("changeaddress/",views.changeaddress,name='changeaddress'),
    path("address/",views.address,name='address'),
    path("build/",views.build,name='build'),
    path("viewbuildcart/",views.viewbuildcart,name='viewbuildcart'),
    path("buildcart/<int:pk>",views.buildCart,name='buildcart'),
    path("produtByCategory/<int:pk>",views.produtByCategory,name='produtByCategory'),
    path("allbuildcartaddtoorders/",views.allbuildcartaddtoorders,name='allbuildcartaddtoorders'),
    path("removeproductfrombuildcart/<int:pk>",views.removeproductfrombuildcart,name='removeproductfrombuildcart'),
    path("rateproduct",views.rateproduct,name='rateproduct'),

 
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)