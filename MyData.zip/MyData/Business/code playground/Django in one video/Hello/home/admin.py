from django.contrib import admin
from home.models import Contact,buynow, orders, productCategory, orderStatus,cart,buildcart
from home.models import FilesUpload,product,firstCarousel,secondCarousel,thirdCarousel,userAddres,review

class AdminOrders(admin.ModelAdmin):
    list_display = ['orderDate','orderStatus','userID','productID']

class AdminProducts(admin.ModelAdmin):
    list_display = ['product_name','product_category',]

# Register your models here.
admin.site.register(Contact)
admin.site.register(FilesUpload)
admin.site.register(product,AdminProducts)
admin.site.register(firstCarousel)
admin.site.register(secondCarousel)
admin.site.register(thirdCarousel)
admin.site.register(userAddres)
admin.site.register(buynow)
admin.site.register(orders,AdminOrders)
admin.site.register(productCategory)
admin.site.register(orderStatus)
admin.site.register(cart)
admin.site.register(buildcart)
admin.site.register(review)








